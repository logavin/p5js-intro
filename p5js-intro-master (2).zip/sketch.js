/*
function setup(){
createCanvas(800,600);
background(255,13,255);
stroke(255);
fill(0)
ellipse(200, 200, 100)
ellipse(400, 200, 100)
rect(140,130,100,10)
rect(340,130,100,10)
ellipse(300, 400, 100,50)
}
*/
var radius,r;

function setup(){
    createCanvas(500,500)
    background(255)
    radius = 0
    r=600
}   
function draw(){
    radius++;
    if (radius<300){
        ellipse(150,150,radius);
    }
    else if(radius>=300){
        background(255)
        ellipse(150,150, r-radius);
        if(radius>=600){
            radius=0
        }
    }
}

