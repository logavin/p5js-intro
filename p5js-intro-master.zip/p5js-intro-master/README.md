# p5js-intro
This is an introductory course to learning p5.js.

### How to use
Download the entire folder and then write javascript code inside `first-p5-project/sketch.js` file. Follow the tutorial in this repo's Wiki: https://github.com/skyrockprojects/p5js-intro/wiki
